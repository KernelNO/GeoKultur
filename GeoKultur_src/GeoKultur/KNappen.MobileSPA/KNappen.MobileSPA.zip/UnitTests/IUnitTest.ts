/// <reference path="../Scripts/typings/jquery/jquery.d.ts" />
// Interface
module UnitTests
{
    export interface IUnitTest {
        runTest(resultwindow: JQuery);
    }
}
