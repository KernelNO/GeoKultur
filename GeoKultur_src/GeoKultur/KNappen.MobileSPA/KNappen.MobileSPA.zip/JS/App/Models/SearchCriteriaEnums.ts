/**
    Model modules
    @namespace App.Models
*/
module App.Models
{
    export enum SearchCriteriaSortingEnum
    {
        Distance = 0,
        Subject = 1,
        PublishingDate = 2
    }

}