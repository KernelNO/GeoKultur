﻿var App;
(function (App) {
    /// <reference path="../_References.ts" />
    /**
    Providers
    @namespace App.Providers
    */
    (function (Providers) {
        var TranslationProviderEN = (function () {
            /**
            TranslationProviderNB
            @class App.Providers.TranslationProviderNB
            @classdesc Provides norwegian (bokmål) translation
            */
            function TranslationProviderEN() {
            }
            /**
            PreInit adds translation for the selected english words, into norwegian
            @method App.Providers.TranslationProviderNB#PreInit
            @public
            */
            TranslationProviderEN.prototype.Load = function () {
                log.debug("TranslationProviderNB", "Load()");

                // Add translation for Norsk Bokmål
                translater.addTranslation("TIMEOUT", "Timeout");
                translater.addTranslation("TIMEOUT_SEARCH_TOTAL", "Timeout during search; {0} of {1} sources returned data.");
                translater.addTranslation("TIMEOUT_NORVEGIANA_SEARCH", "Timeout searching Norvegiana.");
                translater.addTranslation("TIMEOUT_NORVEGIANA_RETRY", "Retrying search...");
                translater.addTranslation("SETTINGS", "Settings");
                translater.addTranslation("SETTINGS_SAVED", "Settings has been saved.");
                translater.addTranslation("UNDEFINED", "Undefined");
                translater.addTranslation("PreCache", "Precache");
            };
            return TranslationProviderEN;
        })();
        Providers.TranslationProviderEN = TranslationProviderEN;
    })(App.Providers || (App.Providers = {}));
    var Providers = App.Providers;
})(App || (App = {}));

var translationProviderEN = new App.Providers.TranslationProviderEN();
startup.addLoad(function () {
    translationProviderEN.Load();
}, "TranslationProviderEN");
//@ sourceMappingURL=TranslationProviderEN.js.map
