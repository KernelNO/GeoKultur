//@ sourceMappingURL=ISearchProvider.js.map
